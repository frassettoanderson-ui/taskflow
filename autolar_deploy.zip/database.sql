-- ============================================================================
--  Autolar Automóveis e Imóveis  —  Estrutura do banco + dados de exemplo
-- ============================================================================
--  Como usar:
--    1) No hPanel da Hostinger, crie um banco MySQL e um usuário.
--    2) Abra o phpMyAdmin daquele banco.
--    3) Aba "Importar" > selecione este arquivo > Executar.
--       (ou cole o conteúdo na aba "SQL" e execute)
--
--  Charset: utf8mb4 (suporta acentos e emojis).
-- ============================================================================

SET NAMES utf8mb4;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;

-- ----------------------------------------------------------------------------
--  Administradores do painel
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome`        VARCHAR(120) NOT NULL,
  `email`       VARCHAR(160) NOT NULL,
  `senha_hash`  VARCHAR(255) NOT NULL,
  `criado_em`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admins_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Admin inicial. A SENHA AINDA NÃO ESTÁ DEFINIDA (hash inválido de propósito).
-- >>> Após importar, acesse /admin/instalar.php para definir a senha. <<<
INSERT INTO `admins` (`nome`, `email`, `senha_hash`) VALUES
('Administrador', 'admin@autolar.com.br', 'DEFINIR_VIA_INSTALADOR');

-- ----------------------------------------------------------------------------
--  Veículos
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `veiculos`;
CREATE TABLE `veiculos` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `marca`       VARCHAR(60)  NOT NULL,
  `modelo`      VARCHAR(120) NOT NULL,
  `versao`      VARCHAR(120) NULL,
  `ano`         SMALLINT UNSIGNED NOT NULL,
  `ano_modelo`  SMALLINT UNSIGNED NULL,
  `preco`       DECIMAL(12,2) NOT NULL DEFAULT 0,
  `km`          INT UNSIGNED NOT NULL DEFAULT 0,
  `cambio`      ENUM('manual','automatico','automatizado','cvt') NOT NULL DEFAULT 'manual',
  `combustivel` ENUM('flex','gasolina','diesel','eletrico','hibrido','gnv') NOT NULL DEFAULT 'flex',
  `cor`         VARCHAR(40)  NULL,
  `portas`      TINYINT UNSIGNED NULL,
  `categoria`   ENUM('hatch','sedan','suv','picape','eletrico','utilitario','cupe','outro') NOT NULL DEFAULT 'outro',
  `descricao`   TEXT NULL,
  `destaque`    TINYINT(1) NOT NULL DEFAULT 0,
  `ativo`       TINYINT(1) NOT NULL DEFAULT 1,
  `status`      ENUM('disponivel','reservado','vendido') NOT NULL DEFAULT 'disponivel',
  `criado_em`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_veic_marca`  (`marca`),
  KEY `idx_veic_ano`    (`ano`),
  KEY `idx_veic_preco`  (`preco`),
  KEY `idx_veic_categoria` (`categoria`),
  KEY `idx_veic_combustivel` (`combustivel`),
  KEY `idx_veic_cambio` (`cambio`),
  KEY `idx_veic_flags`  (`ativo`, `destaque`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `veiculo_imagens`;
CREATE TABLE `veiculo_imagens` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `veiculo_id`  INT UNSIGNED NOT NULL,
  `arquivo`     VARCHAR(255) NOT NULL,
  `ordem`       INT NOT NULL DEFAULT 0,
  `capa`        TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_vimg_veic` (`veiculo_id`),
  CONSTRAINT `fk_vimg_veic` FOREIGN KEY (`veiculo_id`)
      REFERENCES `veiculos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `veiculo_diferenciais`;
CREATE TABLE `veiculo_diferenciais` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `veiculo_id`  INT UNSIGNED NOT NULL,
  `nome`        VARCHAR(80) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vdif_veic` (`veiculo_id`),
  KEY `idx_vdif_nome` (`nome`),
  CONSTRAINT `fk_vdif_veic` FOREIGN KEY (`veiculo_id`)
      REFERENCES `veiculos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
--  Imóveis
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `imoveis`;
CREATE TABLE `imoveis` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `titulo`      VARCHAR(160) NULL,
  `finalidade`  ENUM('venda','aluguel') NOT NULL DEFAULT 'venda',
  `tipo`        ENUM('casa','apartamento','terreno','comercial','sitio','sobrado') NOT NULL DEFAULT 'casa',
  `cidade`      VARCHAR(80)  NOT NULL,
  `bairro`      VARCHAR(80)  NULL,
  `endereco`    VARCHAR(180) NULL,
  `preco`       DECIMAL(14,2) NOT NULL DEFAULT 0,
  `condominio`  DECIMAL(12,2) NULL,
  `quartos`     TINYINT UNSIGNED NULL,
  `suites`      TINYINT UNSIGNED NULL,
  `banheiros`   TINYINT UNSIGNED NULL,
  `vagas`       TINYINT UNSIGNED NULL,
  `area`        DECIMAL(10,2) NULL,
  `area_total`  DECIMAL(10,2) NULL,
  `descricao`   TEXT NULL,
  `destaque`    TINYINT(1) NOT NULL DEFAULT 0,
  `novo`        TINYINT(1) NOT NULL DEFAULT 0,
  `ativo`       TINYINT(1) NOT NULL DEFAULT 1,
  `status`      ENUM('disponivel','reservado','vendido','alugado') NOT NULL DEFAULT 'disponivel',
  `criado_em`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_imv_finalidade` (`finalidade`),
  KEY `idx_imv_tipo`    (`tipo`),
  KEY `idx_imv_cidade`  (`cidade`),
  KEY `idx_imv_bairro`  (`bairro`),
  KEY `idx_imv_preco`   (`preco`),
  KEY `idx_imv_quartos` (`quartos`),
  KEY `idx_imv_flags`   (`ativo`, `destaque`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `imovel_imagens`;
CREATE TABLE `imovel_imagens` (
  `id`        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `imovel_id` INT UNSIGNED NOT NULL,
  `arquivo`   VARCHAR(255) NOT NULL,
  `ordem`     INT NOT NULL DEFAULT 0,
  `capa`      TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_iimg_imv` (`imovel_id`),
  CONSTRAINT `fk_iimg_imv` FOREIGN KEY (`imovel_id`)
      REFERENCES `imoveis` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `imovel_diferenciais`;
CREATE TABLE `imovel_diferenciais` (
  `id`        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `imovel_id` INT UNSIGNED NOT NULL,
  `nome`      VARCHAR(80) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_idif_imv` (`imovel_id`),
  KEY `idx_idif_nome` (`nome`),
  CONSTRAINT `fk_idif_imv` FOREIGN KEY (`imovel_id`)
      REFERENCES `imoveis` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
--  Mensagens do formulário de contato
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `mensagens`;
CREATE TABLE `mensagens` (
  `id`        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome`      VARCHAR(120) NOT NULL,
  `contato`   VARCHAR(160) NOT NULL,
  `assunto`   VARCHAR(160) NULL,
  `mensagem`  TEXT NOT NULL,
  `lida`      TINYINT(1) NOT NULL DEFAULT 0,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_msg_lida` (`lida`),
  KEY `idx_msg_data` (`criado_em`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
--  DADOS DE EXEMPLO (seed) — pode apagar depois de testar
-- ============================================================================

-- ---- Veículos --------------------------------------------------------------
INSERT INTO `veiculos`
(`id`,`marca`,`modelo`,`versao`,`ano`,`ano_modelo`,`preco`,`km`,`cambio`,`combustivel`,`cor`,`portas`,`categoria`,`descricao`,`destaque`,`ativo`,`status`) VALUES
(1,'Hyundai','Creta','1.0 TGDI Platinum',2023,2024,139900.00,18500,'automatico','flex','Cinza',4,'suv','SUV completo, revisões em dia, multimídia com Android Auto e CarPlay, câmera de ré, controle de cruzeiro adaptativo.',1,1,'disponivel'),
(2,'Toyota','Hilux','SRX 2.8 4x4 Diesel',2022,2022,289900.00,46000,'automatico','diesel','Prata',4,'picape','Picape robusta, tração 4x4, couro, central multimídia, ideal para trabalho e lazer.',1,1,'disponivel'),
(3,'Honda','Civic','EXL 2.0 CVT',2021,2021,134900.00,39000,'cvt','flex','Preto',4,'sedan','Sedã premium, bancos em couro, teto solar, completo, único dono.',1,1,'disponivel'),
(4,'BYD','Dolphin','EV 150kW',2024,2024,149900.00,4200,'automatico','eletrico','Branco',4,'eletrico','100% elétrico, autonomia urbana excelente, carregamento rápido, garantia de fábrica.',1,1,'disponivel'),
(5,'Volkswagen','Polo','TSI Highline',2022,2023,98900.00,31000,'automatico','flex','Vermelho',4,'hatch','Hatch turbo, econômico e divertido de dirigir, multimídia, sensores de estacionamento.',0,1,'disponivel'),
(6,'Jeep','Compass','Limited 1.3 T270',2021,2021,144900.00,52000,'automatico','flex','Branco',4,'suv','SUV familiar, teto solar panorâmico, central multimídia de 10", bancos em couro.',0,1,'disponivel'),
(7,'Chevrolet','Onix','Plus LTZ 1.0 Turbo',2023,2023,89900.00,22000,'automatico','flex','Cinza',4,'sedan','Sedã compacto completo, baixo consumo, garantia de fábrica vigente.',0,1,'disponivel'),
(8,'Fiat','Toro','Volcano 2.0 Diesel 4x4',2022,2022,179900.00,41000,'automatico','diesel','Verde',4,'picape','Picape diesel 4x4, capota marítima, central multimídia, pronta para a estrada.',1,1,'disponivel'),
(9,'Renault','Kwid','Outsider 1.0',2023,2024,72900.00,15000,'manual','flex','Laranja',4,'hatch','Compacto econômico, ótimo primeiro carro, baixo custo de manutenção.',0,1,'reservado'),
(10,'Ford','Ranger','XLT 3.2 4x4 Diesel',2020,2020,209900.00,78000,'automatico','diesel','Prata',4,'picape','Picape forte e confiável, revisada, pneus novos, ideal para trabalho pesado.',0,1,'disponivel'),
(11,'Nissan','Kicks','Advance 1.6 CVT',2021,2021,99900.00,48000,'cvt','flex','Azul',4,'suv','SUV urbano econômico, multimídia, câmera de ré, completo.',0,1,'disponivel'),
(12,'Volkswagen','T-Cross','Comfortline 200 TSI',2022,2022,124900.00,33000,'automatico','flex','Branco',4,'suv','SUV espaçoso, porta-malas generoso, central multimídia, baixa quilometragem.',0,1,'disponivel');

INSERT INTO `veiculo_diferenciais` (`veiculo_id`,`nome`) VALUES
(1,'Único dono'),(1,'Teto solar'),(1,'Multimídia'),
(2,'4x4'),(2,'Couro'),(2,'7 lugares'),
(3,'Único dono'),(3,'Teto solar'),(3,'Couro'),
(4,'Garantia de fábrica'),(4,'Carregamento rápido'),
(6,'Teto solar'),(6,'Couro'),
(8,'4x4'),(8,'Capota marítima'),
(10,'4x4'),
(12,'Único dono');

-- ---- Imóveis ---------------------------------------------------------------
INSERT INTO `imoveis`
(`id`,`titulo`,`finalidade`,`tipo`,`cidade`,`bairro`,`endereco`,`preco`,`condominio`,`quartos`,`suites`,`banheiros`,`vagas`,`area`,`descricao`,`destaque`,`novo`,`ativo`,`status`) VALUES
(1,'Apartamento à beira-mar com 3 dormitórios','venda','apartamento','Imbituba','Praia do Rosa','Av. Beira Mar, 1500',890000.00,650.00,3,1,2,2,112.00,'Apartamento amplo a poucos passos da praia, sacada com churrasqueira, vista para o mar, condomínio com piscina e academia.',1,1,1,'disponivel'),
(2,'Casa em condomínio fechado','venda','casa','Imbituba','Vila Nova',NULL,720000.00,NULL,3,1,3,2,180.00,'Casa moderna em condomínio fechado, ampla área gourmet, jardim e garagem para 2 carros.',1,0,1,'disponivel'),
(3,'Terreno plano em bairro residencial','venda','terreno','Imbituba','Centro',NULL,320000.00,NULL,NULL,NULL,NULL,NULL,360.00,'Terreno plano e murado, pronto para construir, excelente localização próxima ao comércio.',1,1,1,'disponivel'),
(4,'Apartamento compacto mobiliado','aluguel','apartamento','Imbituba','Centro',NULL,2200.00,420.00,2,NULL,1,1,58.00,'Apartamento mobiliado e decorado, pronto para morar, próximo a tudo.',1,1,1,'disponivel'),
(5,'Sobrado amplo com piscina','venda','sobrado','Garopaba','Ambrósio',NULL,1250000.00,NULL,4,2,4,3,260.00,'Sobrado de alto padrão com piscina aquecida, área gourmet completa e acabamento premium.',0,0,1,'disponivel'),
(6,'Sala comercial no centro','aluguel','comercial','Imbituba','Centro',NULL,3500.00,800.00,NULL,NULL,2,2,90.00,'Sala comercial ampla e bem localizada, recepção, copa e dois banheiros.',0,0,1,'disponivel'),
(7,'Casa geminada 2 dormitórios','venda','casa','Imbituba','Nova Brasília',NULL,395000.00,NULL,2,NULL,2,1,75.00,'Casa nova, pronta para morar, ótimo acabamento, em rua tranquila.',0,1,1,'disponivel'),
(8,'Apartamento 1 dormitório vista mar','aluguel','apartamento','Garopaba','Centro',NULL,2800.00,500.00,1,1,1,1,48.00,'Studio aconchegante com vista para o mar, ideal para temporada ou moradia.',1,1,1,'disponivel'),
(9,'Sítio com 5.000 m²','venda','sitio','Imbituba','Mirim',NULL,680000.00,NULL,3,1,2,4,5000.00,'Sítio com casa sede, pomar, nascente e muito verde, a poucos minutos da cidade.',0,0,1,'disponivel'),
(10,'Apartamento alto padrão 3 suítes','venda','apartamento','Imbituba','Praia do Rosa',NULL,1480000.00,950.00,3,3,4,2,145.00,'Cobertura com 3 suítes, terraço com piscina privativa e vista panorâmica para o mar.',1,1,1,'disponivel');

INSERT INTO `imovel_diferenciais` (`imovel_id`,`nome`) VALUES
(1,'Piscina'),(1,'Academia'),(1,'Vista para o mar'),(1,'Churrasqueira'),
(2,'Condomínio fechado'),(2,'Área gourmet'),(2,'Jardim'),
(4,'Mobiliado'),
(5,'Piscina'),(5,'Área gourmet'),(5,'Alto padrão'),
(8,'Vista para o mar'),(8,'Mobiliado'),
(10,'Piscina privativa'),(10,'Vista para o mar'),(10,'Alto padrão');

-- ---- Mensagens de exemplo --------------------------------------------------
INSERT INTO `mensagens` (`nome`,`contato`,`assunto`,`mensagem`,`lida`) VALUES
('Maria Silva','maria@email.com','Interesse em imóvel','Olá, gostaria de mais informações sobre o apartamento à beira-mar.',0),
('João Pereira','(48) 98888-7777','Avaliação de veículo','Tenho um carro para negociar na compra de outro. Como funciona?',0);

SET foreign_key_checks = 1;

-- ============================================================================
--  FIM. Próximo passo: acesse /admin/instalar.php para definir a senha do admin.
-- ============================================================================
